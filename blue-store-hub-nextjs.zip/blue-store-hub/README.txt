Blue Store Hub - Next.js starter
--------------------------------
This project is a Next.js starter prefilled with 110 informational entries about "Steal a Brainrot" and "Blue Store".

How to run locally:
1. npm install
2. npm run dev
3. Open http://localhost:3000

Deploy to Vercel:
- Connect your Git repo or drag & drop this project to Vercel, it will detect Next.js automatically.